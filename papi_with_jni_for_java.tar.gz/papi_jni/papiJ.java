public class papiJ {

/** Current version number **/
public static final int PAPI_VER_CURRENT = 83886080;

public native int PAPI_JNI_library_init(int i);
public native int PAPI_JNI_start(int i);
public native int PAPI_JNI_stop(int i);

 
static {
    System.out.println("loading...");

    System.loadLibrary("papitry");
  }

}
