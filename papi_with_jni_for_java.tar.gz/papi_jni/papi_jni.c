#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#include <papi.h>
#include "papiJ.h"

using namespace std;

static int Events[] = {
  PAPI_TOT_CYC,
  PAPI_TOT_INS,
  PAPI_L1_DCM,
  PAPI_L2_DCM,
  PAPI_RES_STL,
  PAPI_SR_INS,
  PAPI_HW_INT,
  PAPI_BR_MSP,
  PAPI_L2_STM,
  PAPI_TLB_DM
};

#define NUMEVENTS (sizeof(Events) / sizeof(int))
#define MSIZE 2000
#define THRESHOLD 100000
static int EventSet;

static long_long values[NUMEVENTS];
static double dvalues[NUMEVENTS];

void handler(int EventSet, void *address, long_long overflow_vector, void *context)
{
 int i;

  /* Stop counting events */
  if (PAPI_read(EventSet, values) != PAPI_OK)
  { 
   printf("Error\n");
  return ;
 }

   fprintf(stderr, "handler(%d) Overflow at %p! vector=0x%llx\n",
     EventSet, address, overflow_vector);

  for(i = 0; i < NUMEVENTS; i++) {
    dvalues[i] += i ? (double)values[i] : THRESHOLD;
    /* printf("%15.2lf %15lu\n",dvalues[i], (unsigned long int)values[i]); */
  }

  if (PAPI_reset(EventSet) != PAPI_OK)
   { 
   printf("Error\n");
  return ;
 }

}

void print_results()
{ char eventName[PAPI_MAX_STR_LEN];
  int i;

  for(i = 0; i < NUMEVENTS; i++) {
    if (PAPI_event_code_to_name(Events[i], eventName) != PAPI_OK)
      {
           printf("Error\n");
           return;
       }
    printf("  Event %15s: %15.0lf\n", eventName, dvalues[i]);
  }

}

   
JNIEXPORT jint JNICALL Java_papiJ_PAPI_1JNI_1library_1init
  (JNIEnv *env, jobject obj,jint ver)
{
  jint ret = -1;
  EventSet = PAPI_NULL;
  ret = PAPI_library_init(ver);
  cout << " calling from interface " << ver << " and " << ret << "\n";
  if(ret == -1)
 { 
   printf("Error\n");
  return ret;
 }
 
PAPI_multiplex_init();
int num_hwcntrs = 0;
if ((num_hwcntrs = PAPI_num_counters()) <= PAPI_OK)
{
printf("Error\n");
  return -1;
}
  printf("Hw counters:%d\n",num_hwcntrs);

if(PAPI_create_eventset(&EventSet) != PAPI_OK)
{   
printf("Error\n");
  return -1;
}
printf("eventset created\n");

if (PAPI_assign_eventset_component(EventSet, 0) != PAPI_OK)
{
printf("Error\n");
  return -1;
}
ret = PAPI_set_multiplex(EventSet);
  printf("set mutiplex event ret val: %d\n",ret);


/* add events to our eventset */
  for(int i = 0; i < NUMEVENTS; i++) {
    dvalues[i] = 0.0;
    ret = PAPI_add_event(EventSet, Events[i]);
    if (ret != PAPI_OK)
      {
       printf("Error\n");
        return -1;
       
      }
     printf("Adding even %d : %d   Error = %d\n",i,Events[i],ret);
  }
  ret = PAPI_get_multiplex(EventSet);
  printf("get mutiplex event ret val: %d\n",ret);


printf("This system has %d available counters.\n", num_hwcntrs);
  int num_events = 1*NUMEVENTS;
  printf("We will count %d events.\n", num_events);

if(PAPI_overflow(EventSet, Events[0], THRESHOLD, 0, handler) != PAPI_OK)
{
printf("Error\n");
  return -1;
}

 if(PAPI_overflow(EventSet, Events[1], THRESHOLD, 0, handler) != PAPI_OK)
{
printf("Error\n");
  return -1;
} 

  return ret;
}



JNIEXPORT jint JNICALL Java_papiJ_PAPI_1JNI_1start
  (JNIEnv * env, jobject obj, jint event_set_num)
{
if (PAPI_start(EventSet) != PAPI_OK)
  {
  printf("Error\n");
  return -1;
  }
}

JNIEXPORT jint JNICALL Java_papiJ_PAPI_1JNI_1stop
  (JNIEnv *env , jobject obj, jint event_set_num)
{
  if (PAPI_stop(EventSet, values) != PAPI_OK)
  {
printf("Error\n");
  return -1;
  }
  for(int i = 0; i < NUMEVENTS; i++) {
    dvalues[i] += (double)values[i];
  }

  print_results();
}
