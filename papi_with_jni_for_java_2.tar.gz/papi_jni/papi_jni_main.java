class papi_jni_main {
  
    public static void main(String[] args)
{
 try
{  
papiJ p = new papiJ();
  
  int retVar = p.PAPIJ_library_init(p.PAPI_VER_CURRENT);
  System.out.println(retVar);
  retVar = p.PAPIJ_start(0);
 // System.out.println(retVar);

  //code under test
  
  retVar = p.PAPIJ_stop(0);
  System.out.println(retVar);
}
catch(Exception e)

{
 System.out.println("Caught IOException: " + e.getMessage());
}
}
 
}
